// Roda no contexto da própria página do YouTube.
// 1) Captura as legendas que o player baixa  2) Liga/desliga a legenda no player.
(function () {
  const post = (type, data) =>
    window.postMessage(Object.assign({ source: 'shadowing-ext', type }, data || {}), '*');
  let wasOn = true;

  function handle(url, text) {
    try {
      const u = new URL(url, location.href);
      if (!u.pathname.includes('/api/timedtext')) return;
      if (u.searchParams.get('tlang')) return;
      if (!text) return;
      post('TIMEDTEXT', {
        videoId: u.searchParams.get('v'),
        lang: u.searchParams.get('lang') || '',
        asr: u.searchParams.get('kind') === 'asr',
        text
      });
    } catch (e) {}
  }

  const origFetch = window.fetch;
  window.fetch = function (...args) {
    const p = origFetch.apply(this, args);
    try {
      const url = typeof args[0] === 'string' ? args[0] : (args[0] && args[0].url) || '';
      if (url.includes('/api/timedtext')) p.then(r => r.clone().text().then(t => handle(url, t))).catch(() => {});
    } catch (e) {}
    return p;
  };

  const origOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (method, url) {
    const u = String(url);
    if (u.includes('/api/timedtext')) {
      this.addEventListener('load', () => {
        try {
          let t = '';
          if (this.responseType === '' || this.responseType === 'text') t = this.responseText;
          else if (this.responseType === 'json') t = JSON.stringify(this.response);
          else if (this.response instanceof ArrayBuffer) t = new TextDecoder().decode(this.response);
          handle(u, t);
        } catch (e) {}
      });
    }
    return origOpen.apply(this, arguments);
  };

  function enable(lang) {
    let tries = 0, first = true;
    const go = () => {
      const p = document.querySelector('#movie_player');
      if (!p || !p.getOption || !p.loadModule) {
        if (tries++ < 20) return setTimeout(go, 400);
        return post('STATUS', { ok: false, reason: 'player' });
      }
      if (first) {
        first = false;
        try { const cur = p.getOption('captions', 'track'); wasOn = !!(cur && cur.languageCode); } catch (e) { wasOn = true; }
      }
      try { p.loadModule('captions'); } catch (e) {}
      const list = p.getOption('captions', 'tracklist') || [];
      if (!list.length && tries++ < 12) return setTimeout(go, 400);
      const matches = list.filter(t => (t.languageCode || '').toLowerCase().startsWith(lang));
      if (!matches.length) return post('STATUS', { ok: false, reason: 'nolang', langs: list.map(t => t.languageCode) });
      const isAsr = t => t.kind === 'asr' || (t.vss_id || '').startsWith('a.');
      const track = matches.find(t => !isAsr(t)) || matches[0];
      try { p.setOption('captions', 'track', {}); } catch (e) {}
      setTimeout(() => { try { p.setOption('captions', 'track', track); } catch (e) {} }, 200);
      post('STATUS', { ok: true, lang: track.languageCode, asr: isAsr(track) });
    };
    go();
  }

  function disable() {
    if (wasOn) return; // o usuário já estava com a legenda ligada: não mexe
    try {
      const p = document.querySelector('#movie_player');
      p.setOption('captions', 'track', {});
      p.unloadModule('captions');
    } catch (e) {}
  }

  window.addEventListener('message', e => {
    if (e.source !== window || !e.data || e.data.source !== 'shadowing-ext-cs') return;
    if (e.data.type === 'ENABLE') enable(e.data.lang);
    if (e.data.type === 'DISABLE') disable();
  });
})();
