// Funções puras (sem acesso à página), compartilhadas com content.js
var SHW = (() => {
  const normalize = s => s.toLowerCase().replace(/[’‘`]/g, "'").replace(/'/g, '').replace(/[^\p{L}\p{N}]/gu, '');

  function splitWords(text, lang) {
    const cjk = lang === 'ja' || lang === 'zh';
    const parts = cjk ? Array.from(text.replace(/\s+/g, '')) : text.split(/\s+/);
    return parts.filter(Boolean).map(raw => ({ raw, norm: normalize(raw) }));
  }

  // Alinha as palavras da frase com as palavras ditas (maior subsequência comum)
  function compare(target, spoken) {
    const n = target.length, m = spoken.length;
    const dp = Array.from({ length: n + 1 }, () => new Array(m + 1).fill(0));
    for (let i = 1; i <= n; i++)
      for (let j = 1; j <= m; j++)
        dp[i][j] = target[i - 1].norm === spoken[j - 1].norm ? dp[i - 1][j - 1] + 1 : Math.max(dp[i - 1][j], dp[i][j - 1]);
    const ok = new Array(n).fill(false);
    let i = n, j = m;
    while (i > 0 && j > 0) {
      if (target[i - 1].norm === spoken[j - 1].norm) { ok[i - 1] = true; i--; j--; }
      else if (dp[i - 1][j] >= dp[i][j - 1]) i--; else j--;
    }
    return ok;
  }

  // Divide um trecho transcrito em frases, repartindo o tempo pelo tamanho de cada uma
  function splitSentences(text, s, e) {
    const parts = (text.match(/[^.!?。！？]+[.!?。！？]*["”’']*\s*/g) || [text]).map(p => p.trim()).filter(Boolean);
    if (parts.length <= 1) return [{ start: s, end: e, text: text.trim() }];
    const total = parts.reduce((a, p) => a + p.length, 0);
    let t = s;
    return parts.map(p => { const d = (e - s) * p.length / total; const c = { start: t, end: t + d, text: p }; t += d; return c; });
  }

  function floatToB64(f32) {
    const i16 = new Int16Array(f32.length);
    for (let i = 0; i < f32.length; i++) { const x = Math.max(-1, Math.min(1, f32[i])); i16[i] = x < 0 ? x * 32768 : x * 32767; }
    const bytes = new Uint8Array(i16.buffer);
    let bin = '';
    for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    return btoa(bin);
  }

  function concat(arrs, total) {
    const out = new Float32Array(total);
    let o = 0;
    for (const a of arrs) { out.set(a, o); o += a.length; }
    return out;
  }

  function rms(f32) {
    let s = 0;
    for (let i = 0; i < f32.length; i++) s += f32[i] * f32[i];
    return Math.sqrt(s / Math.max(1, f32.length));
  }

  return { normalize, splitWords, compare, splitSentences, floatToB64, concat, rms };
})();
