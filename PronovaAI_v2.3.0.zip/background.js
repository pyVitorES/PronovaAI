// Pronova AI: mensagens rápidas; trabalhos longos seguem por eventos (sem canal pendurado).
let creating = null;
async function ensureOffscreen() {
  if (creating) return creating;
  creating = (async () => {
    if (await chrome.offscreen.hasDocument()) return;
    try {
      await chrome.offscreen.createDocument({url:'offscreen.html',reasons:['WORKERS'],
        justification:'Reconhecimento de voz local com Whisper'});
    } catch (e) {
      if (!String(e).includes('single offscreen')) throw e;
    }
  })();
  try { await creating; } finally { creating = null; }
}
async function forward(msg) {
  await ensureOffscreen();
  return await chrome.runtime.sendMessage({...msg,target:'offscreen'});
}
chrome.runtime.onMessage.addListener((msg,sender,sendResponse) => {
  if (!msg) return;
  if (msg.target === 'background') {
    (async () => {
      try { sendResponse((await forward(msg)) || {error:'O módulo de voz não respondeu.'}); }
      catch (e) { sendResponse({error:String(e.message||e)}); }
    })();
    return true;
  }
  if (msg.target === 'relay') {
    // Eventos destinados apenas a abas com o YouTube aberto.
    chrome.tabs.query({url:['https://www.youtube.com/*','https://www.netflix.com/*']}).then(tabs =>
      Promise.all(tabs.map(t => chrome.tabs.sendMessage(t.id,msg.payload).catch(()=>{})))
    ).catch(()=>{});
    sendResponse({ok:true});
    return false;
  }
});
