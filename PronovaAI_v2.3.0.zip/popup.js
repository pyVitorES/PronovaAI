const defaults = {lang:'en',quality:'tiny',pass:80,shadow:true,watchMode:true,rate:1,blur:false,advance:true,enabled:true};
const fieldIds=['lang','quality','pass','watchMode','shadow'];
const PIX_KEY='cfbd4c58-3317-4a2e-8fcf-d04592c5277a';
let platform='youtube';
let state={...defaults};
const $=id=>document.getElementById(id);
const platformKey=()=>platform+'Settings';
function hint(){ $('quality-hint').textContent=state.quality==='base'?'Melhor reconhecimento, porém pode usar mais memória e demorar mais (~80 MB).':'Modelo menor e mais rápido, mas pode cometer mais erros (~40 MB).'; }
function render(){
  for(const id of fieldIds) $(id).value=String(state[id]);
  $('enabled').checked=state.enabled;
  $('tab-youtube').setAttribute('aria-selected',String(platform==='youtube'));
  $('tab-netflix').setAttribute('aria-selected',String(platform==='netflix'));
  $('switch-title').textContent='Pronova AI no '+(platform==='youtube'?'YouTube':'Netflix');
  $('switch-caption').textContent=state.enabled?'Ativado. Desative para assistir sem interrupções.':'Desativado. Seus vídeos não serão pausados pelo Pronova.';
  $('settings-fields').classList.toggle('disabled-fields',!state.enabled);
  $('platform-note').textContent=platform==='netflix'
    ? 'Netflix: ative as legendas no próprio player. O Pronova lê apenas o texto exibido. A compatibilidade pode variar com atualizações da Netflix. Não captura conteúdo protegido.'
    : 'Primeiro uso: a IA pode levar alguns minutos para baixar o modelo de voz, que fica salvo localmente quando possível.';
  hint();
}
function choose(next){
  if (next === 'donate') {
    $('tab-youtube').setAttribute('aria-selected','false');
    $('tab-netflix').setAttribute('aria-selected','false');
    $('tab-donate').setAttribute('aria-selected','true');
    $('practice-panel').hidden=true;
    $('donation-panel').hidden=false;
    return;
  }
  $('tab-donate').setAttribute('aria-selected','false');
  $('practice-panel').hidden=false;
  $('donation-panel').hidden=true;
  platform=next;
  chrome.storage.sync.get([platformKey(),'lang','quality','pass','shadow','rate','blur','advance'],data=>{
    const legacy=platform==='youtube'?Object.fromEntries(Object.keys(defaults).filter(k=>k in data).map(k=>[k,data[k]])):{};
    const saved = data[platformKey()] || {};
    state={...defaults,...legacy,...saved};
    if (!saved.speedDefaultV229) {
      if (state.rate === 0.8) state.rate = 1;
      chrome.storage.sync.set({ [platformKey()]: { ...saved, rate: state.rate, speedDefaultV229: true } });
    }
    render();
  });
}
function set(key,value){
  state[key]=value;
  const storeKey=platformKey();
  chrome.storage.sync.get({[storeKey]:{}},v=>chrome.storage.sync.set({[storeKey]:{...(v[storeKey]||{}),[key]:value}}));
  render();
}
document.querySelectorAll('[data-platform]').forEach(button=>button.addEventListener('click',()=>choose(button.dataset.platform)));
$('enabled').addEventListener('change',e=>set('enabled',e.target.checked));
for(const id of fieldIds) $(id).addEventListener('change',e=>set(id,id==='pass'?Number(e.target.value):(id==='shadow'||id==='watchMode')?e.target.value==='true':e.target.value));
chrome.tabs.query({active:true,currentWindow:true},tabs=>choose((tabs[0]?.url||'').includes('netflix.com')?'netflix':'youtube'));

$('copy-pix').addEventListener('click', async () => {
  const status=$('copy-status');
  try {
    await navigator.clipboard.writeText(PIX_KEY);
    status.textContent='Chave Pix copiada! 💚';
  } catch (error) {
    status.textContent='Não foi possível copiar automaticamente. Selecione a chave acima para copiar.';
  }
});
