(() => {
  if (window.__shwLoaded) return;
  window.__shwLoaded = true;

  const LANGS = { en: 'inglês', es: 'espanhol', fr: 'francês', de: 'alemão', it: 'italiano', ja: 'japonês', ko: 'coreano', zh: 'chinês', ru: 'russo', pt: 'português' };
  const SR_TAGS = { en: 'en-US', es: 'es-ES', fr: 'fr-FR', de: 'de-DE', it: 'it-IT', ja: 'ja-JP', ko: 'ko-KR', zh: 'zh-CN', ru: 'ru-RU', pt: 'pt-BR' };
  const platform = location.hostname.includes('netflix.com') ? 'netflix' : 'youtube';
  const storageKey = platform + 'Settings';
  const defaults = { lang: 'en', quality: 'tiny', pass: 80, shadow: true, watchMode: true, rate: 1, blur: false, advance: true, enabled: true };
  const settings = { ...defaults };
  const saveSetting = (key, value) => {
    chrome.storage.sync.get({[storageKey]: {}}, data => {
      chrome.storage.sync.set({[storageKey]: {...(data[storageKey] || {}),[key]:value}});
    });
  };
  let netflixObserver = null, lastNetflixText = '', netflixLastSeen = 0, netflixSubtitleTimer = null;
  let videoRateBefore = null;
  let pausedByPronova = false;
  let replayLockUntil = 0, replayIndex = -1, playbackRequest = 0;
  let originalReplay = null; // reprodução temporária do próprio player, sem capturar áudio
  let pendingAdvance = -1; // Netflix: índice aguardado ou em reprodução depois de acertar
  let pendingAdvancePlaying = false; // true somente depois que a próxima fala começar

  const AC = window.AudioContext || window.webkitAudioContext;
  const CHUNK_SEC = 15;
  const isBrave = !!navigator.brave;

  let cues = [], cuesAsr = null, cuesSource = '', armed = -1, shown = -1, panel = null, panelPos = null;
  let loadToken = 0, rafId = 0, failTimer = 0, advTimer = 0;
  let practicing = false, practiceIdx = -1, rec = null, mediaRec = null, stream = null, chunks = [], vad = null;
  let srText = '', speechSeen = false, myAudioUrl = null, myAudio = null;
  let tx = null;

  const video = () => platform === 'netflix' ? document.querySelector('video') : document.querySelector('video.html5-main-video');
  const currentVideoId = () => platform === 'netflix' ? location.pathname : new URLSearchParams(location.search).get('v');
  const $ = sel => panel && panel.querySelector(sel);
  const cjk = () => settings.lang === 'ja' || settings.lang === 'zh';
  const modelName = () => `Xenova/whisper-${settings.quality}${settings.lang === 'en' ? '.en' : ''}`;
  const send = msg => chrome.runtime.sendMessage(Object.assign({ target: 'background' }, msg));
  const requests = new Map();
  const asr = async (f32, timestamps) => {
    const requestId = crypto.randomUUID();
    return new Promise((resolve, reject) => {
      // Limpa requisições que falharem sem resposta, sem prender canais do Chrome.
      const timer = setTimeout(() => { requests.delete(requestId); reject(new Error('A transcrição demorou demais. Tente outra vez.')); }, 10 * 60 * 1000);
      requests.set(requestId, result => { clearTimeout(timer); resolve(result); });
      send({ type: 'ASR', requestId, model: modelName(), lang: settings.lang,
        timestamps: !!timestamps, audio: SHW.floatToB64(f32) })
        .then(r => { if (!r || r.error) { const done = requests.get(requestId); requests.delete(requestId);
          if (done) done({error:(r && r.error)||'O módulo de voz não respondeu.'}); } })
        .catch(e => { const done = requests.get(requestId); requests.delete(requestId);
          if(done) done({error:String(e.message||e)}); });
    });
  };
  const preloadModel = () => { send({ type: 'LOAD', model: modelName() }).catch(e => {
    const el = $('#shw-model'); if (el) { el.hidden = false; el.textContent = '⚠️ Não consegui iniciar o modelo: ' + e.message; }
  }); };

  // ================= Legendas do YouTube =================
  function parseTimedText(text) {
    const out = [];
    text = (text || '').trim();
    if (!text) return out;
    if (text[0] === '{') {
      let data; try { data = JSON.parse(text); } catch (e) { return out; }
      for (const ev of data.events || []) {
        if (!ev.segs) continue;
        const t = ev.segs.map(s => s.utf8).join('').replace(/\s+/g, ' ').trim();
        if (!t) continue;
        const start = ev.tStartMs / 1000;
        out.push({ start, end: start + (ev.dDurationMs || 2000) / 1000, text: t });
      }
    } else if (text[0] === '<') {
      const doc = new DOMParser().parseFromString(text, 'text/xml');
      const ps = doc.querySelectorAll('p');
      if (ps.length) {
        ps.forEach(p => {
          const t = p.textContent.replace(/\s+/g, ' ').trim();
          if (!t) return;
          const start = +p.getAttribute('t') / 1000;
          out.push({ start, end: start + (+p.getAttribute('d') || 2000) / 1000, text: t });
        });
      } else {
        doc.querySelectorAll('text').forEach(n => {
          const t = n.textContent.replace(/\s+/g, ' ').trim();
          if (!t) return;
          const start = +n.getAttribute('start');
          out.push({ start, end: start + (+n.getAttribute('dur') || 2), text: t });
        });
      }
    }
    for (let i = 0; i < out.length - 1; i++) if (out[i].end > out[i + 1].start) out[i].end = out[i + 1].start;
    return out.filter(c => c.end - c.start > 0.2);
  }

  function onTimedText(d) {
    if (platform !== 'youtube' || !panel || d.videoId !== currentVideoId()) return;
    if (!d.lang.toLowerCase().startsWith(settings.lang)) return;
    if (cues.length && cuesAsr === false && d.asr) return;
    const parsed = parseTimedText(d.text);
    if (!parsed.length) return;
    stopTranscribe();
    cues = parsed; cuesAsr = d.asr; cuesSource = 'youtube'; armed = -1; shown = -1;
    clearTimeout(failTimer);
    document.documentElement.classList.remove('shw-capturing');
    window.postMessage({ source: 'shadowing-ext-cs', type: 'DISABLE' }, '*');
    setInfo(`✓ Legenda do YouTube carregada: ${cues.length} frases${d.asr ? ' (automática, pode ter erros)' : ''}`);
    $('#shw-text').textContent = '▶ Dê play no vídeo';
  }

  function onStatus(d) {
    if (platform !== 'youtube' || !panel || cues.length) return;
    if (d.ok) return setInfo(`Carregando legenda em ${LANGS[settings.lang]}…`);
    if (d.reason === 'nolang') startFallback(`Este vídeo não tem legenda em ${LANGS[settings.lang]}.`);
    else startFallback('Não consegui acessar as legendas do YouTube.');
  }

  window.addEventListener('message', e => {
    if (e.source !== window || !e.data || e.data.source !== 'shadowing-ext') return;
    if (e.data.type === 'TIMEDTEXT') onTimedText(e.data);
    if (e.data.type === 'STATUS') onStatus(e.data);
  });

  chrome.runtime.onMessage.addListener(m => {
    if (!m) return;
    if (m.type === 'ASR_RESULT') {
      const done = requests.get(m.requestId);
      if (done) { requests.delete(m.requestId); done(m); }
      return;
    }
    if (m.type !== 'ASR_PROGRESS' || !panel) return;
    const el = $('#shw-model');
    if (m.state === 'downloading') { el.hidden = false; el.textContent = `⬇️ Preparando arquivos da IA: ${m.pct}% dos arquivos identificados. O percentual pode variar enquanto novos arquivos são encontrados.`; }
    else if (m.state === 'loading') { el.hidden = false; el.textContent = '⏳ Preparando o modelo de voz…'; }
    else if (m.state === 'ready') el.hidden = true;
    else if (m.state === 'error') { el.hidden = false; el.textContent = '⚠️ Erro ao carregar o modelo de voz: ' + m.message; }
  });

  // ================= Transcrição do áudio (vídeos sem legenda) =================
  function startFallback(reason) {
    if (platform === 'netflix' || !settings.enabled || cues.length || tx || !panel) return;
    clearTimeout(failTimer);
    cuesSource = 'audio';
    setInfo(`${reason} Vou transcrever o áudio automaticamente com IA (roda no seu computador). Dê play no vídeo e as frases vão aparecendo.`);
    preloadModel();
    const v = video();
    if (!v) return;
    if (!v.paused) startTranscribe();
    else v.addEventListener('playing', () => startTranscribe(), { once: true });
  }

  function startTranscribe(tries = 0) {
    if (platform === 'netflix' || !settings.enabled || tx || !panel || (cues.length && cuesSource !== 'audio')) return;
    const v = video();
    if (!v) return;
    let st = null;
    try { st = v.captureStream ? v.captureStream() : null; } catch (e) {}
    if (!st || !st.getAudioTracks().length) {
      if (tries < 10) return void setTimeout(() => startTranscribe(tries + 1), 800);
      return setInfo('Não consegui capturar o áudio deste vídeo.');
    }
    const ctx = new AC({ sampleRate: 16000 });
    const src = ctx.createMediaStreamSource(new MediaStream(st.getAudioTracks()));
    const proc = ctx.createScriptProcessor(4096, 1, 1);
    tx = { ctx, src, proc, buf: [], samples: 0, startVT: 0, pending: 0, doneUntil: -1 };
    proc.onaudioprocess = onAudio;
    src.connect(proc); proc.connect(ctx.destination);
    if (ctx.resume) ctx.resume();
    v.addEventListener('pause', onMediaBreak);
    v.addEventListener('seeking', onMediaBreak);
    updateTxInfo();
  }

  function stopTranscribe() {
    if (!tx) return;
    const v = video();
    if (v) { v.removeEventListener('pause', onMediaBreak); v.removeEventListener('seeking', onMediaBreak); }
    try { tx.proc.disconnect(); tx.src.disconnect(); tx.ctx.close(); } catch (e) {}
    tx = null;
  }

  function onAudio(e) {
    const v = video();
    if (!tx || !v || v.paused || v.seeking) return;
    const data = e.inputBuffer.getChannelData(0);
    if (!tx.samples) tx.startVT = Math.max(0, v.currentTime - (data.length / 16000) * v.playbackRate);
    tx.buf.push(new Float32Array(data));
    tx.samples += data.length;
    if (tx.samples >= CHUNK_SEC * 16000) flushChunk(v.currentTime);
  }

  function onMediaBreak() { const v = video(); if (tx && v) flushChunk(v.currentTime); }

  function flushChunk(endVT) {
    if (!tx || !tx.samples) return;
    const samples = tx.samples, startVT = tx.startVT;
    const audio = SHW.concat(tx.buf, samples);
    tx.buf = []; tx.samples = 0;
    if (samples < 16000 * 2) return;                 // trecho curto demais
    if (startVT < tx.doneUntil - 1) return;           // trecho já transcrito (usuário voltou o vídeo)
    if (SHW.rms(audio) < 0.003) return;               // silêncio
    const scale = Math.max(0.1, endVT - startVT) / (samples / 16000);
    tx.pending++; updateTxInfo();
    asr(audio, true).then(res => {
      if (!tx) return;
      tx.pending--;
      if (!res || res.error) { setInfo('⚠️ Erro na transcrição: ' + ((res && res.error) || 'sem resposta')); return; }
      tx.doneUntil = Math.max(tx.doneUntil, endVT);
      addAudioCues(res, startVT, scale, samples / 16000);
      updateTxInfo();
    }).catch(e => { if (tx) { tx.pending--; setInfo('⚠️ Erro na transcrição: ' + e.message); } });
  }

  function addAudioCues(res, startVT, scale, audioDur) {
    const segs = res.chunks && res.chunks.length ? res.chunks : [{ timestamp: [0, audioDur], text: res.text || '' }];
    let added = 0;
    for (const sg of segs) {
      const text = (sg.text || '').trim();
      if (!text || /^[\[\(♪\*].*[\]\)♪\*]$/.test(text)) continue; // [música], (aplausos)…
      const s = (sg.timestamp && sg.timestamp[0]) || 0;
      const e = (sg.timestamp && sg.timestamp[1] != null) ? sg.timestamp[1] : audioDur;
      for (const c of SHW.splitSentences(text, startVT + s * scale, startVT + e * scale)) { cues.push(c); added++; }
    }
    if (!added) return;
    cues.sort((a, b) => a.start - b.start);
    cuesAsr = true; shown = -1;
    if ($('#shw-text') && $('#shw-text').textContent.startsWith('▶')) $('#shw-text').textContent = '…';
  }

  function updateTxInfo() {
    if (!tx) return;
    setInfo(`🎙️ Transcrevendo o áudio com IA… ${cues.length} frases prontas${tx.pending ? ` (processando ${tx.pending} trecho${tx.pending > 1 ? 's' : ''})` : ''}. As frases aparecem alguns segundos depois de tocarem; use ⏮ e 🔁 para praticar o que já passou.`);
  }

  // ================= Painel =================
  function setInfo(msg) { const el = $('#shw-info'); if (el) el.textContent = msg; }

  function buildPanel() {
    panel = document.createElement('div');
    panel.id = 'shw-panel';
    panel.innerHTML = `
      <div class="shw-head" id="shw-drag">
        <img class="shw-logo" alt="" src="${chrome.runtime.getURL('icons/icon48.png')}">
        <span class="shw-title">Pronova AI · ${platform === 'netflix' ? 'Netflix' : 'YouTube'}</span>
        <span class="shw-badge">${LANGS[settings.lang]}</span>
        <span class="shw-spacer"></span>
        <button class="shw-icon" id="shw-min" title="Minimizar">–</button>
      </div>
      <div class="shw-body">
        <div class="shw-info" id="shw-info"></div>
        <div class="shw-disclaimer">⚠️ O Pronova AI está em desenvolvimento. A IA pode cometer erros na transcrição e na avaliação da sua pronúncia.</div>
        <div class="shw-model" id="shw-model" hidden></div>
        <div class="shw-text" id="shw-text">…</div>
        <div class="shw-status" id="shw-status"></div>
        ${platform === 'netflix' ? '<div class="shw-disclaimer">Ouvir original, Anterior e Próxima usam o player da Netflix. As posições são aproximadas e só incluem legendas já identificadas.</div>' : ''}
        <div class="shw-nav">
          <button id="shw-prev" title="Frase anterior (Alt+J)">⏮ Anterior</button>
          <button id="shw-repeat" title="Repetir frase (Alt+K)">🔁 Ouvir original</button>
          <button id="shw-next" title="Próxima frase (Alt+L)">Próxima ⏭</button>
        </div>
        <button class="shw-mic" id="shw-mic" title="Atalho: Alt+M">🎤 Falar a frase</button>
        <button class="shw-continue" id="shw-continue" title="Despausar e continuar o vídeo (Alt+P)">▶ Prosseguir</button>
        <div class="shw-result" id="shw-result" hidden></div>
        <details class="shw-opts" open>
          <summary>Opções</summary>
          <div class="shw-speed-control">
            <label for="shw-rate"><span class="shw-speed-icon">⏩</span><span>Velocidade do vídeo<small>Controle a velocidade de reprodução</small></span></label>
            <select id="shw-rate" aria-label="Velocidade de reprodução">${[0.5, 0.6, 0.7, 0.8, 0.9, 1, 1.25, 1.5].map(r => `<option value="${r}">${r}x${r === 1 ? ' · Normal' : ''}</option>`).join('')}</select>
          </div>
          <label><input type="checkbox" id="shw-watch-mode"> 🎬 Assistir sem interrupções (praticar quando quiser)</label>
          <label><input type="checkbox" id="shw-shadow"> Pausar automaticamente quando o modo livre estiver desligado</label>
          <label><input type="checkbox" id="shw-advance"> Avançar quando eu acertar</label>
          <label><input type="checkbox" id="shw-blur"> Esconder o texto (treinar ouvindo)</label>
        </details>
      </div>`;
    if (panelPos) { panel.style.left = panelPos.left; panel.style.top = panelPos.top; panel.style.right = 'auto'; }
    (document.fullscreenElement || document.body).appendChild(panel);

    $('#shw-rate').value = String(settings.rate);
    $('#shw-watch-mode').checked = settings.watchMode;
    $('#shw-shadow').checked = settings.shadow;
    $('#shw-advance').checked = settings.advance;
    $('#shw-blur').checked = settings.blur;
    document.documentElement.classList.toggle('shw-hide-native', settings.blur);
    $('#shw-text').classList.toggle('shw-blur', settings.blur);

    $('#shw-min').onclick = () => { panel.classList.toggle('shw-collapsed'); $('#shw-min').textContent = panel.classList.contains('shw-collapsed') ? '+' : '–'; };
    $('#shw-prev').onclick = () => go(-1);
    $('#shw-next').onclick = () => go(1);
    $('#shw-repeat').onclick = () => repeatCurrentCue();
    $('#shw-mic').onclick = togglePractice;
    $('#shw-continue').onclick = continueWatching;
    $('#shw-rate').onchange = e => { settings.rate = parseFloat(e.target.value); const v = video(); if (v) v.playbackRate = settings.rate; saveSetting('rate', settings.rate); };
    $('#shw-watch-mode').onchange = e => { settings.watchMode = e.target.checked; saveSetting('watchMode', settings.watchMode); if (settings.watchMode) { armed = -1; pausedByPronova = false; } setInfo(settings.watchMode ? '🎬 Modo livre: o vídeo continua. Use Anterior ou Ouvir original para praticar.' : 'Modo de pausas automáticas ativado conforme suas opções.'); };
    $('#shw-shadow').onchange = e => { settings.shadow = e.target.checked; saveSetting('shadow', settings.shadow); };
    $('#shw-advance').onchange = e => { settings.advance = e.target.checked; saveSetting('advance', settings.advance); };
    $('#shw-blur').onchange = e => {
      settings.blur = e.target.checked;
      $('#shw-text').classList.toggle('shw-blur', settings.blur);
      document.documentElement.classList.toggle('shw-hide-native', settings.blur);
      saveSetting('blur', settings.blur);
    };
    $('#shw-text').onclick = () => $('#shw-text').classList.toggle('shw-reveal');
    enableDrag($('#shw-drag'));
    const v = video();
    if (v) { videoRateBefore = v.playbackRate; if (platform !== 'netflix') v.playbackRate = settings.rate; v.addEventListener('seeking', onSeeking); }
  }

  // arrastar o painel
  let drag = null;
  function enableDrag(handle) {
    handle.addEventListener('mousedown', e => {
      if (e.target.closest('button')) return;
      const r = panel.getBoundingClientRect();
      drag = { sx: e.clientX, sy: e.clientY, ox: r.left, oy: r.top };
      e.preventDefault();
    });
  }
  window.addEventListener('mousemove', e => {
    if (!drag || !panel) return;
    panel.style.left = Math.max(0, Math.min(innerWidth - 120, drag.ox + e.clientX - drag.sx)) + 'px';
    panel.style.top = Math.max(0, Math.min(innerHeight - 50, drag.oy + e.clientY - drag.sy)) + 'px';
    panel.style.right = 'auto';
  });
  window.addEventListener('mouseup', () => { if (drag && panel) panelPos = { left: panel.style.left, top: panel.style.top }; drag = null; });
  document.addEventListener('fullscreenchange', () => { if (panel) (document.fullscreenElement || document.body).appendChild(panel); });

  function teardown() {
    cancelAnimationFrame(rafId); clearTimeout(failTimer); clearTimeout(advTimer); pendingAdvance = -1; pendingAdvancePlaying = false;
    stopTranscribe();
    cleanupMedia();
    stopNetflix();
    cancelOriginalReplay();
    if ('speechSynthesis' in window) speechSynthesis.cancel();
    replayLockUntil = 0; replayIndex = -1; playbackRequest++;
    if (platform === 'youtube') window.postMessage({source:'shadowing-ext-cs',type:'DISABLE'},'*');
    if (pausedByPronova && !practicing) { const player = video(); if (player && player.paused) player.play().catch(()=>{}); }
    pausedByPronova = false;
    if (panel) panel.remove();
    panel = null; cues = []; cuesAsr = null; cuesSource = ''; armed = -1; shown = -1; practicing = false;
    document.documentElement.classList.remove('shw-capturing', 'shw-hide-native');
    const v = video(); if (v) { v.removeEventListener('seeking', onSeeking); if (videoRateBefore !== null && platform !== 'netflix') v.playbackRate = videoRateBefore; } videoRateBefore = null;
  }

  // Lê APENAS o texto de legenda renderizado pela Netflix, sem capturar áudio protegido/DRM.
  // Os seletores podem mudar quando a Netflix atualiza seu player.
  const netflixSelectors = [
    '.player-timedtext', '.player-timedtext-text-container',
    '[data-uia="subtitle-text"]', '[data-uia="player-subtitle-text"]'
  ];
  function subtitleText() {
    for (const selector of netflixSelectors) {
      const nodes = [...document.querySelectorAll(selector)].filter(el => {
        const st = getComputedStyle(el);
        return st.display !== 'none' && st.visibility !== 'hidden' && el.getClientRects().length;
      });
      if (nodes.length) {
        // Usar o elemento principal, evitando duplicar textos de filhos.
        const root = nodes.find(n => !nodes.some(x => x !== n && x.contains(n))) || nodes[0];
        return (root.innerText || root.textContent || '').replace(/\s+/g,' ').trim();
      }
    }
    return '';
  }
  // Ignora exclusivamente o conteúdo delimitado por colchetes nas legendas da Netflix.
  // Preserve qualquer texto fora de [...], sem classificar falas por palavras-chave.
  function spokenNetflixText(raw) {
    return (raw || '')
      .replace(/\[[^\]]*\]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }
  function collectNetflixSubtitle() {
    if (!panel || !settings.enabled || platform !== 'netflix' || originalReplay) return;
    const v = video(); if (!v || !Number.isFinite(v.currentTime)) return;
    const raw = subtitleText();
    const str = spokenNetflixText(raw);
    const time = v.currentTime;
    // Não cria uma frase se a legenda contiver apenas conteúdo entre colchetes.
    if (str && str !== lastNetflixText) {
      if (cues.length && lastNetflixText) {
        const previousIdx = cues.length - 1;
        const previous = cues[previousIdx];
        previous.end = Math.max(previous.start + .2, time);
        // Depois do acerto, deixe a nova frase ser ouvida INTEIRA.
        // Ao aparecer a legenda seguinte, a frase anterior acabou: pause agora.
        if (pendingAdvancePlaying && pendingAdvance === previousIdx && !practicing) {
          pendingAdvance = -1; pendingAdvancePlaying = false;
          pauseAt(previousIdx, v);
          setInfo('✅ Frase ouvida até o final. Agora é sua vez de praticar!');
        } else if (pendingAdvance < 0 && !settings.watchMode && settings.shadow && !v.paused && !practicing && time > previous.start + .25 && Date.now() > replayLockUntil) {
          pauseAt(previousIdx, v);
        }
      }
      lastNetflixText = str;
      netflixLastSeen = Date.now();
      if (cues.length && cues[cues.length - 1].text === str && Math.abs(time-cues[cues.length-1].end)<1) return;
      const existing = cues.findIndex(c => c.text === str && Math.abs(c.start - time) < 2.2);
      if (existing !== -1) { setText(existing); return; }
      cues.push({start:time, end:time+Math.max(1.5,Math.min(6,str.length/12)), text:str});
      if (pendingAdvance >= 0 && !pendingAdvancePlaying && cues.length - 1 > pendingAdvance) {
        const nextIdx = cues.length - 1;
        pendingAdvance = nextIdx;
        pendingAdvancePlaying = true;
        setText(nextIdx);
        setInfo('🔊 Ouça a próxima frase. O Pronova vai pausar quando ela terminar.');
      }
      cuesSource = 'netflix'; cuesAsr = false;
      if (cues.length > 1200) { cues.splice(0,300); shown = -1; armed = -1; }
      if (!pendingAdvancePlaying) setInfo('✓ Netflix: '+cues.length+' falas identificadas (trechos entre colchetes ignorados).');
      return;
    }
    if (!str && lastNetflixText) {
      const last = cues[cues.length - 1];
      if (last) {
        last.end = Math.max(last.start + .2, time);
        if (pendingAdvancePlaying && pendingAdvance === cues.length - 1 && !practicing) {
          const finishedIdx = pendingAdvance;
          pendingAdvance = -1; pendingAdvancePlaying = false;
          pauseAt(finishedIdx, v);
          setInfo('✅ Frase ouvida até o final. Agora é sua vez de praticar!');
        } else if (pendingAdvance < 0 && !settings.watchMode && settings.shadow && !v.paused && !practicing && time > last.start + .25 && Date.now() > replayLockUntil) pauseAt(cues.length - 1, v);
      }
      lastNetflixText = '';
    }
  }
  function startNetflix() {
    lastNetflixText = '';
    setInfo('🎬 Modo livre: assista normalmente. As falas são guardadas; use Anterior ou Ouvir original quando quiser praticar.');
    netflixObserver = new MutationObserver(mutations => { if (mutations.some(m => !panel?.contains(m.target))) collectNetflixSubtitle(); });
    netflixObserver.observe(document.body,{childList:true,subtree:true,characterData:true,attributes:false});
    netflixSubtitleTimer = setInterval(collectNetflixSubtitle, 350);
  }
  function stopNetflix() {
    if (netflixObserver) netflixObserver.disconnect();
    netflixObserver = null;
    clearInterval(netflixSubtitleTimer);
    netflixSubtitleTimer = null;
    lastNetflixText = '';
  }

  function load() {
    const token = ++loadToken;
    teardown();
    if (!settings.enabled) return;
    if (platform === 'youtube' && location.pathname !== '/watch') return;
    if (platform === 'netflix' && !location.pathname.startsWith('/watch/')) return;
    buildPanel();
    startLoop();
    if (platform === 'netflix') {
      startNetflix();
      return;
    }
    document.documentElement.classList.add('shw-capturing');
    setInfo(`Procurando legenda em ${LANGS[settings.lang]}…`);
    if (isBrave) preloadModel();
    window.postMessage({ source: 'shadowing-ext-cs', type: 'ENABLE', lang: settings.lang }, '*');
    failTimer = setTimeout(() => {
      if (token === loadToken && !cues.length) startFallback('Não consegui obter as legendas do YouTube.');
    }, 10000);
  }

  // Netflix: busca temporal via API do próprio player (mundo MAIN),
  // nunca por atribuição direta de video.currentTime, que causa erro de reprodução.
  let netflixCommandId = 0;
  function netflixControl(action, timeSec) {
    const id = 'pronova-' + (++netflixCommandId) + '-' + Math.random().toString(36).slice(2);
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        window.removeEventListener('pronova:netflix:response', handler);
        reject(new Error('Netflix não respondeu ao comando do player.'));
      }, 2400);
      function handler(e) {
        if (e.detail?.id !== id) return;
        clearTimeout(timer);
        window.removeEventListener('pronova:netflix:response', handler);
        if (e.detail.ok) resolve(e.detail);
        else reject(new Error(e.detail.error || 'Controle da Netflix indisponível'));
      }
      window.addEventListener('pronova:netflix:response', handler);
      window.dispatchEvent(new CustomEvent('pronova:netflix:command', {
        detail: {id, action, timeMs: Number.isFinite(timeSec) ? Math.round(timeSec * 1000) : null}
      }));
    });
  }
  async function seekCue(v, target) {
    if (platform !== 'netflix') { v.currentTime = target; return; }
    await netflixControl('seek', target);
    // API confirma o comando; o seek pode demorar para concluir.
    await new Promise(resolve => {
      let done = false;
      const end = () => { if (done) return; done = true; v.removeEventListener('seeked', end); resolve(); };
      v.addEventListener('seeked', end);
      setTimeout(end, 1700);
    });
    if (Math.abs(v.currentTime - target) > 5) throw new Error('A Netflix não confirmou a posição do trecho.');
  }
  async function playerPlay(v) {
    if (platform === 'netflix') return netflixControl('play');
    return v.play();
  }
  async function playerPause(v) {
    if (platform === 'netflix') return netflixControl('pause');
    return v.pause();
  }

  // ================= Reprodução =================
  function findCue(t) { for (let i = 0; i < cues.length; i++) if (t >= cues[i].start && t < cues[i].end) return i; return -1; }
  function nearestIdx(t) { let idx = 0; for (let i = 0; i < cues.length; i++) if (cues[i].start <= t + 0.05) idx = i; return idx; }
  function onSeeking() { if (Date.now() > replayLockUntil) armed = -1; }

  function cancelOriginalReplay() {
    if (!originalReplay) return;
    originalReplay = null;
    replayLockUntil = 0;
    replayIndex = -1;
    playbackRequest++;
  }

  // Repetição de áudio ORIGINAL: nunca armazena, grava ou descriptografa o conteúdo.
  // Apenas solicita que o próprio player volte ao intervalo da legenda.
  async function replayOriginalCue(idx) {
    pendingAdvance = -1; pendingAdvancePlaying = false;
    const v = video();
    const cue = cues[idx];
    if (!v || !cue || !panel || !settings.enabled) return;
    if (practicing) cancelPractice();
    cancelOriginalReplay();
    clearTimeout(advTimer);
    if ('speechSynthesis' in window) speechSynthesis.cancel();

    // Legendas da Netflix são identificadas ao aparecerem na tela, portanto
    // a marcação de tempo é aproximada e não substitui timings nativos.
    const start = Math.max(0, cue.start - (platform === 'netflix' ? 0.45 : 0.12));
    const end = Math.max(start + 0.65, Math.min(cue.end, start + 18));
    const oldTime = v.currentTime;
    if (!Number.isFinite(start) || !Number.isFinite(end)) return;
    if (platform === 'netflix' && Math.abs(start - oldTime) > 120) {
      setInfo('Este trecho está muito longe na reprodução. Volte mais perto da frase pelo próprio player.');
      return;
    }
    const requestId = ++playbackRequest;
    originalReplay = {requestId, idx, end, video: v, pathname: location.pathname, startedAt: Date.now(), reachedStart: false};
    replayIndex = idx;
    replayLockUntil = Date.now() + 16000;
    armed = -1;
    shown = idx;
    setText(idx);
    setInfo('🔊 Reproduzindo a voz original pelo próprio vídeo…');
    try {
      // Evita que o controle de pausas de shadowing interrompa a repetição.
      await seekCue(v, start);
      if (!originalReplay || originalReplay.requestId !== requestId || !panel) return;
      if (platform === 'netflix' && (location.pathname !== originalReplay.pathname || Math.abs(v.currentTime - start) > 4)) {
        cancelOriginalReplay();
        setInfo('A Netflix não permitiu voltar a esse trecho. Use o botão de voltar do próprio player.');
        return;
      }
      if (platform !== 'netflix') v.playbackRate = settings.rate;
      await playerPlay(v);
      if (originalReplay && originalReplay.requestId === requestId) {
        originalReplay.reachedStart = true;
        pausedByPronova = false;
      }
    } catch (err) {
      if (originalReplay && originalReplay.requestId === requestId) {
        cancelOriginalReplay();
        setInfo('O player não permitiu repetir a voz original: ' + (err.message || err) + '. Use os controles do vídeo.');
      }
    }
  }

  // Prosseguir: retoma o player do ponto atual, sem pular legendas nem sintetizar voz.
  // Usa a mesma API de player da v2.2.5 na Netflix para não alterar currentTime.
  async function continueWatching() {
    const v = video();
    if (!v || !panel || !settings.enabled) return setInfo('Não encontrei um vídeo ativo para continuar.');
    pendingAdvance = -1; pendingAdvancePlaying = false;
    clearTimeout(advTimer);
    cancelOriginalReplay();
    if (practicing) cancelPractice();
    if ('speechSynthesis' in window) speechSynthesis.cancel();
    armed = -1;
    pausedByPronova = false;
    replayLockUntil = Date.now() + 800;
    try {
      await playerPlay(v);
      if (!panel || !settings.enabled) return;
      setInfo(settings.watchMode
        ? '▶ Reprodução retomada. Continue assistindo e escolha quando praticar.'
        : '▶ Reprodução retomada. A próxima pausa seguirá suas configurações.');
      const status = $('#shw-status');
      if (status) status.textContent = '';
    } catch (err) {
      setInfo('Não consegui continuar o vídeo: ' + (err.message || err));
    }
  }

  function repeatCurrentCue() {
    const v = video();
    if (!v || !cues.length) return setInfo('Espere a legenda aparecer para repetir a fala.');
    const idx = shown !== -1 ? shown : nearestIdx(v.currentTime);
    replayOriginalCue(idx);
  }
  function go(delta) {
    pendingAdvance = -1; pendingAdvancePlaying = false;
    clearTimeout(advTimer);
    cancelOriginalReplay();
    const v = video(); if (!v || !cues.length) return;
    const base = shown !== -1 ? shown : nearestIdx(v.currentTime);
    const i = Math.max(0, Math.min(cues.length - 1, base + delta));
    if (platform === 'netflix' && delta > 0 && base >= cues.length - 1) {
      setInfo('A próxima fala ainda não foi identificada. Continue o episódio para carregá-la.');
      return;
    }
    if (practicing) cancelPractice();
    shown = -1;
    setText(i);
    if (platform === 'netflix') {
      // Próxima/Anterior: voltar ao INÍCIO temporal da fala identificada.
      // Não gera voz artificial nem manipula o elemento de vídeo diretamente.
      replayOriginalCue(i);
      return;
    }
    // Evita que o loop de pausas interrompa o rewind antes da frase tocar.
    const requestId = ++playbackRequest;
    replayIndex = i;
    replayLockUntil = Date.now() + 1100;
    armed = -1;
    pausedByPronova = false;
    const target = Math.max(0, cues[i].start - .08);
    try {
      v.currentTime = target;
      v.playbackRate = settings.rate;
      Promise.resolve(v.play()).then(() => {
        if (requestId !== playbackRequest) return;
        replayLockUntil = Date.now() + 400;
        armed = i;
      }).catch(err => setInfo('Não consegui reproduzir a frase: ' + (err.message || err)));
    } catch (err) { setInfo('Falha ao voltar para a frase: ' + err.message); }
  }

  function setText(i) {
    if (i === shown || !panel) return;
    shown = i;
    const el = $('#shw-text');
    el.classList.remove('shw-reveal');
    el.textContent = i === -1 ? '…' : cues[i].text;
    if (!practicing) $('#shw-result').hidden = true;
  }

  function pauseAt(idx, v) {
    if (originalReplay || Date.now() < replayLockUntil) return;
    if (platform === 'netflix') playerPause(v).catch(() => {});
    else v.pause();
    pausedByPronova = true;
    if (platform !== 'netflix') v.currentTime = Math.max(cues[idx].start, cues[idx].end - 0.02);
    armed = -1;
    setText(idx);
    const st = $('#shw-status');
    st.textContent = '🎤 Sua vez! Clique em “Falar a frase”';
    setTimeout(() => { if (st) st.textContent = ''; }, 6000);
  }

  function startLoop() {
    const tick = () => {
      const v = video();
      if (originalReplay && v && originalReplay.video === v) {
        const rep = originalReplay;
        // Acaba no final da frase, deixando o player pausado para o aluno falar.
        if (rep.reachedStart && v.currentTime >= rep.end - 0.06) {
          cancelOriginalReplay();
          if (platform === 'netflix') playerPause(v).catch(err => setInfo('Não consegui pausar o player: ' + err.message));
          else v.pause();
          pausedByPronova = true;
          armed = -1;
          setText(rep.idx);
          if (platform === 'netflix') lastNetflixText = spokenNetflixText(subtitleText());
          setInfo('✓ Trecho original reproduzido. Agora é sua vez de falar!');
        } else if (Date.now() - rep.startedAt > 16000 || (rep.reachedStart && v.paused)) {
          cancelOriginalReplay();
          setInfo('Reprodução interrompida. Clique em “Ouvir original” para tentar novamente.');
        }
        rafId = requestAnimationFrame(tick);
        return;
      }
      if (settings.enabled && v && panel && cues.length && !practicing) {
        const t = v.currentTime, i = findCue(t);
        if (!v.paused) {
          if (i !== -1) {
            if (platform !== 'netflix' && armed !== -1 && i !== armed && !settings.watchMode && settings.shadow && Date.now() > replayLockUntil) pauseAt(armed, v);
            else { armed = i; setText(i); }
          } else if (platform !== 'netflix' && armed !== -1 && t > cues[armed].end && !settings.watchMode && settings.shadow && Date.now() > replayLockUntil) pauseAt(armed, v);
        } else if (i !== -1) setText(i);
      }
      rafId = requestAnimationFrame(tick);
    };
    rafId = requestAnimationFrame(tick);
  }

  // ================= Pronúncia =================
  function togglePractice() { practicing ? stopPractice() : startPractice(); }

  function renderPlain() { const el = $('#shw-text'); if (el && shown !== -1) el.textContent = cues[shown].text; }

  function colorize(cue, heard) {
    const disp = SHW.splitWords(cue.text, settings.lang);
    const scored = disp.filter(t => t.norm);
    const spoken = SHW.splitWords(heard, settings.lang).filter(t => t.norm);
    const ok = SHW.compare(scored, spoken);
    const el = $('#shw-text');
    el.textContent = '';
    const sep = cjk() ? '' : ' ';
    let k = 0;
    disp.forEach(t => {
      const s = document.createElement('span');
      if (t.norm) s.className = ok[k++] ? 'shw-ok' : 'shw-miss';
      s.textContent = t.raw + sep;
      el.appendChild(s);
    });
    const good = ok.filter(Boolean).length;
    return { score: scored.length ? Math.round(100 * good / scored.length) : 0 };
  }

  async function startPractice() {
    pendingAdvance = -1; pendingAdvancePlaying = false;
    clearTimeout(advTimer);
    cancelOriginalReplay();
    const v = video();
    if (!v || !cues.length) return setInfo('Espere as frases carregarem antes de praticar.');
    if ('speechSynthesis' in window) speechSynthesis.cancel();
    try { await playerPause(v); } catch (err) { return setInfo('Não foi possível pausar para praticar: ' + err.message); }
    pausedByPronova = false;
    practiceIdx = shown !== -1 ? shown : nearestIdx(v.currentTime);
    setText(practiceIdx);
    shown = practiceIdx;
    renderPlain();
    $('#shw-text').classList.remove('shw-reveal');
    srText = ''; speechSeen = false; chunks = [];
    const box = $('#shw-result');
    box.hidden = false;
    box.textContent = '🎤 Pedindo acesso ao microfone…';
    try {
      stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
    } catch (e) {
      box.textContent = '⚠️ Não consegui acessar o microfone. Clique no cadeado ao lado do endereço, permita o microfone e tente de novo.';
      return;
    }
    practicing = true;
    setMicState(true);
    box.textContent = '🔴 Pode falar! Vou parar sozinho quando você terminar.';
    if (!isBrave) preloadModel();

    try {
      mediaRec = new MediaRecorder(stream);
      mediaRec.ondataavailable = e => { if (e.data && e.data.size) chunks.push(e.data); };
      mediaRec.start();
    } catch (e) { mediaRec = null; }
    startVad();

    // Chrome/Edge: reconhecimento do navegador (instantâneo). Brave: usa o Whisper local.
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SR && !isBrave) {
      try {
        rec = new SR();
        rec.lang = SR_TAGS[settings.lang] || 'en-US';
        rec.interimResults = true;
        rec.continuous = true;
        rec.onresult = e => {
          srText = Array.from(e.results).map(r => r[0].transcript).join(' ').trim();
          if (practicing && srText) colorize(cues[practiceIdx], srText);
        };
        rec.onerror = () => {};
        rec.start();
      } catch (e) { rec = null; }
    }
  }

  function startVad() {
    try {
      const ctx = new AC();
      const src = ctx.createMediaStreamSource(stream);
      const an = ctx.createAnalyser();
      an.fftSize = 1024;
      src.connect(an);
      if (ctx.resume) ctx.resume();
      const buf = new Float32Array(an.fftSize);
      const t0 = Date.now();
      let lastVoice = 0;
      const timer = setInterval(() => {
        an.getFloatTimeDomainData(buf);
        const level = SHW.rms(buf), now = Date.now();
        if (level > 0.015) { speechSeen = true; lastVoice = now; }
        if (speechSeen && now - lastVoice > 1500) stopPractice();
        else if (!speechSeen && now - t0 > 9000) stopPractice();
        else if (now - t0 > 25000) stopPractice();
      }, 80);
      vad = { ctx, timer };
    } catch (e) { vad = null; }
  }

  function setMicState(on) {
    const b = $('#shw-mic');
    if (!b) return;
    b.textContent = on ? '⏹ Terminei' : '🎤 Falar a frase';
    b.classList.toggle('shw-recording', on);
  }

  function cleanupMedia() {
    if (vad) { clearInterval(vad.timer); try { vad.ctx.close(); } catch (e) {} vad = null; }
    try { rec && rec.abort(); } catch (e) {}
    try { mediaRec && mediaRec.state !== 'inactive' && mediaRec.stop(); } catch (e) {}
    if (stream) stream.getTracks().forEach(t => t.stop());
    rec = null; mediaRec = null; stream = null;
  }

  function cancelPractice() { practicing = false; cleanupMedia(); setMicState(false); }

  function stopPractice() {
    if (!practicing) return;
    practicing = false;
    setMicState(false);
    if (vad) { clearInterval(vad.timer); try { vad.ctx.close(); } catch (e) {} vad = null; }
    try { rec && rec.stop(); } catch (e) {}
    try { mediaRec && mediaRec.state !== 'inactive' && mediaRec.stop(); } catch (e) {}
    $('#shw-result').textContent = '⏳ Avaliando sua pronúncia…';
    setTimeout(finalize, 800);
  }

  async function blobTo16k(blob) {
    const ac = new AC({ sampleRate: 16000 });
    try { return (await ac.decodeAudioData(await blob.arrayBuffer())).getChannelData(0).slice(); }
    finally { ac.close(); }
  }

  async function finalize() {
    const idx = practiceIdx, cue = cues[idx];
    const blob = chunks.length ? new Blob(chunks, { type: chunks[0].type || 'audio/webm' }) : null;
    cleanupMedia();
    if (myAudioUrl) URL.revokeObjectURL(myAudioUrl);
    myAudioUrl = blob ? URL.createObjectURL(blob) : null;
    let text = srText, err = null;
    if (!text && speechSeen && blob) {
      try {
        const res = await asr(await blobTo16k(blob), false);
        if (res && res.error) err = res.error; else text = ((res && res.text) || '').trim();
      } catch (e) { err = String(e.message || e); }
    }
    if (!panel || practicing || idx !== practiceIdx) return;
    renderResult(cue, text, err);
  }

  function renderResult(cue, text, err) {
    const box = $('#shw-result');
    box.hidden = false;
    box.innerHTML = '';
    const add = (cls, txt) => { const d = document.createElement('div'); d.className = cls; d.textContent = txt; box.appendChild(d); return d; };
    let pass = false;
    if (text) {
      const { score } = colorize(cue, text);
      pass = score >= settings.pass;
      $('#shw-text').classList.add('shw-reveal');
      add('shw-score ' + (pass ? 'shw-pass' : 'shw-try'), pass ? `✅ Pronúncia correta! ${score}%` : `💪 Quase lá! ${score}% — precisa de ${settings.pass}%`);
      const bar = document.createElement('div'); bar.className = 'shw-bar';
      const fill = document.createElement('div'); fill.style.width = score + '%'; fill.className = pass ? 'shw-pass-bg' : 'shw-try-bg';
      bar.appendChild(fill); box.appendChild(bar);
      add('shw-heard', 'Entendi: “' + text + '”');
      if (!pass) add('shw-hint', 'Azul = pronunciou certo. Vermelho = não entendi essa palavra; ouça o original e tente de novo.');
    } else if (err) {
      add('shw-warn', '⚠️ Não consegui avaliar: ' + err);
    } else {
      add('shw-warn', '🤔 Não ouvi nada. Fale mais perto do microfone e tente de novo.');
    }
    const row = document.createElement('div');
    row.className = 'shw-row';
    const btn = (label, fn) => { const b = document.createElement('button'); b.textContent = label; b.onclick = fn; row.appendChild(b); };
    if (myAudioUrl) btn('▶ Minha voz', () => { if (myAudio) myAudio.pause(); myAudio = new Audio(myAudioUrl); myAudio.play(); });
    btn('🔊 Ouvir original', () => { shown = practiceIdx; repeatCurrentCue(); });
    btn(pass ? '🎤 Repetir' : '🎤 Tentar de novo', () => { shown = practiceIdx; startPractice(); });
    box.appendChild(row);

    if (pass && settings.advance) {
      const completedIdx = practiceIdx;
      add('shw-hint', completedIdx + 1 < cues.length
        ? 'Indo para a próxima frase…'
        : 'Aguardando a próxima fala para avançar automaticamente…');
      advTimer = setTimeout(async () => {
        if (practicing || !panel || !settings.enabled || practiceIdx !== completedIdx) return;
        if (completedIdx < cues.length - 1) {
          shown = completedIdx;
          go(1);
        } else if (platform === 'netflix') {
          // A Netflix entrega legendas aos poucos: retoma o filme e espera a próxima fala.
          pendingAdvance = completedIdx; pendingAdvancePlaying = false;
          setInfo('✅ Acertou! Aguardando a próxima fala do filme…');
          try { await playerPlay(video()); }
          catch (err) { pendingAdvance = -1; pendingAdvancePlaying = false; setInfo('Não consegui retomar para a próxima fala: ' + err.message); }
        } else {
          setInfo('✅ Acertou! Esta é a última frase disponível.');
        }
      }, 1800);
    }
  }

  // ================= Atalhos e eventos =================
  document.addEventListener('keydown', e => {
    if (!e.altKey || !panel) return;
    const k = e.key.toLowerCase();
    if (k === 'j') { e.preventDefault(); go(-1); }
    if (k === 'k') { e.preventDefault(); repeatCurrentCue(); }
    if (k === 'l') { e.preventDefault(); go(1); }
    if (k === 'm') { e.preventDefault(); togglePractice(); }
    if (k === 'p') { e.preventDefault(); continueWatching(); }
  });
  if (platform === 'youtube') document.addEventListener('yt-navigate-finish', load);
  if (platform === 'netflix') {
    let previousPath = location.pathname;
    setInterval(() => { if (location.pathname !== previousPath) { previousPath = location.pathname; load(); } }, 800);
  }
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== 'sync' || !ch[storageKey]) return;
    const previousEnabled = settings.enabled;
    const previousLang = settings.lang;
    Object.assign(settings, defaults, ch[storageKey].newValue || {});
    if (previousEnabled !== settings.enabled || previousLang !== settings.lang) load();
    else if (panel) {
      $('#shw-watch-mode').checked = settings.watchMode;
      $('#shw-shadow').checked = settings.shadow;
      $('#shw-advance').checked = settings.advance;
      $('#shw-blur').checked = settings.blur;
      $('#shw-rate').value = String(settings.rate);
      const v = video(); if (v) v.playbackRate = settings.rate;
      $('#shw-text').classList.toggle('shw-blur',settings.blur);
    }
  });
  chrome.storage.sync.get([storageKey, 'lang','quality','pass','shadow','rate','blur','advance'], data => {
    // Preserva configurações existentes do YouTube na migração.
    const legacy = platform === 'youtube' ? Object.fromEntries(Object.keys(defaults).filter(k => k in data).map(k => [k,data[k]])) : {};
    const saved = data[storageKey] || {};
    Object.assign(settings, defaults, legacy, saved);
    // Migra o antigo padrão 0,8x uma única vez, sem impedir escolhas futuras.
    if (!saved.speedDefaultV229) {
      if (settings.rate === 0.8) settings.rate = 1;
      chrome.storage.sync.set({ [storageKey]: { ...saved, rate: settings.rate, speedDefaultV229: true } });
    }
    load();
  });
})();
