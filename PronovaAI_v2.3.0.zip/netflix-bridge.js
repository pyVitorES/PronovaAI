// Pronova AI: bridge entre content script e API do player da Netflix.
// Não acessa o vídeo protegido nem captura seu conteúdo; apenas comandos de reprodução.
(() => {
  if (window.__pronovaNetflixBridge) return;
  window.__pronovaNetflixBridge = true;
  function getPlayer() {
    const api = window.netflix?.appContext?.state?.playerApp?.getAPI?.();
    const vp = api?.videoPlayer;
    if (!vp) return null;
    const ids = vp.getAllPlayerSessionIds?.() || [];
    const id = ids.find(x => String(x).startsWith('watch-')) || ids[0];
    return id ? vp.getVideoPlayerBySessionId(id) : null;
  }
  window.addEventListener('pronova:netflix:command', e => {
    const {id, action, timeMs} = e.detail || {};
    if (!id || !['seek','play','pause'].includes(action)) return;
    try {
      const player = getPlayer();
      if (!player) throw new Error('Player Netflix indisponível nesta página.');
      if (action === 'seek') {
        if (!Number.isFinite(timeMs) || timeMs < 0) throw new Error('Posição inválida.');
        player.seek(timeMs);
      } else if (action === 'play') player.play();
      else player.pause();
      window.dispatchEvent(new CustomEvent('pronova:netflix:response', {detail:{id,ok:true}}));
    } catch (err) {
      window.dispatchEvent(new CustomEvent('pronova:netflix:response', {detail:{id,ok:false,error:String(err?.message||err)}}));
    }
  });
})();
