// Whisper executado em um documento offscreen, sem backend remoto de transcrição.
import {pipeline, env} from './lib/transformers.min.js';
env.allowLocalModels = false;
env.useBrowserCache = true;
env.backends.onnx.wasm.wasmPaths = chrome.runtime.getURL('lib/');
env.backends.onnx.wasm.numThreads = 1;
env.backends.onnx.wasm.proxy = false;
const WLANG={en:'english',es:'spanish',fr:'french',de:'german',it:'italian',ja:'japanese',ko:'korean',zh:'chinese',ru:'russian',pt:'portuguese'};
const pipes=new Map(), progress=new Map();
let queue=Promise.resolve();
const relay=payload=>chrome.runtime.sendMessage({target:'relay',payload}).catch(()=>{});
const friendlyError=e=>{
  const msg=String(e?.message||e);
  if (/Unsupported model type: whisper/.test(msg)) return 'Não foi possível carregar o Whisper. Verifique a conexão, o cache do modelo e os arquivos ONNX; se persistir, consulte o console da extensão.';
  if (/fetch|network|failed to load|401|403|404|CORS/i.test(msg)) return 'Falha ao baixar arquivos do modelo. Verifique a internet e tente novamente. Detalhe: '+msg;
  return msg;
};
function onProgress(p) {
  if (p.status === 'initiate' && p.file) progress.set(p.file,{loaded:0,total:0});
  if (p.status === 'progress' && p.file) progress.set(p.file,{loaded:Number(p.loaded)||0,total:Number(p.total)||0});
  if (p.status === 'done' && p.file) {
    const old=progress.get(p.file)||{loaded:0,total:0};
    progress.set(p.file,{loaded:old.total,total:old.total});
  }
  let loaded=0,total=0;
  for (const v of progress.values()) {loaded+=v.loaded;total+=v.total;}
  if (total) relay({type:'ASR_PROGRESS',state:'downloading',pct:Math.min(99,Math.floor(loaded/total*100)),file:p.file||''});
}
function getPipe(model) {
  if (!/^Xenova\/whisper-(tiny|base)(\.en)?$/.test(model)) return Promise.reject(new Error('Modelo de voz inválido.'));
  if (!pipes.has(model)) {
    progress.clear();
    relay({type:'ASR_PROGRESS',state:'loading'});
    const promise=pipeline('automatic-speech-recognition',model,{quantized:true,progress_callback:onProgress})
      .then(p=>{relay({type:'ASR_PROGRESS',state:'ready'});return p;})
      .catch(e=>{pipes.delete(model);console.error('[Pronova] Erro original ao carregar Whisper:',e);
        relay({type:'ASR_PROGRESS',state:'error',message:friendlyError(e)});throw e;});
    pipes.set(model,promise);
  }
  return pipes.get(model);
}
function b64ToFloat32(b64) {
  const bin=atob(b64),n=bin.length>>1,out=new Float32Array(n);
  for(let i=0;i<n;i++){let v=bin.charCodeAt(i*2)|(bin.charCodeAt(i*2+1)<<8);if(v>=32768)v-=65536;out[i]=v/32768;}
  return out;
}
chrome.runtime.onMessage.addListener((msg,sender,sendResponse)=>{
  if(!msg||msg.target!=='offscreen')return;
  if(msg.type==='LOAD') {
    // Nunca segurar uma resposta runtime durante minutos de download.
    getPipe(msg.model).catch(()=>{});
    sendResponse({ok:true,state:'loading'});
    return false;
  }
  if(msg.type==='ASR') {
    const id=msg.requestId;
    if(typeof id!=='string'||id.length>100){sendResponse({error:'Requisição inválida.'});return false;}
    queue=queue.catch(()=>{}).then(async()=>{
      try{
        const asr=await getPipe(msg.model);
        const opts={return_timestamps:!!msg.timestamps};
        if(msg.timestamps){opts.chunk_length_s=30;opts.stride_length_s=5;}
        if(!msg.model.endsWith('.en')){opts.language=WLANG[msg.lang]||'english';opts.task='transcribe';}
        const out=await asr(b64ToFloat32(msg.audio),opts);
        await relay({type:'ASR_RESULT',requestId:id,text:out.text||'',chunks:out.chunks||null});
      }catch(e){console.error('[Pronova] Erro na transcrição:',e);
        await relay({type:'ASR_RESULT',requestId:id,error:friendlyError(e)});}
    });
    sendResponse({ok:true,queued:true});
    return false;
  }
});
